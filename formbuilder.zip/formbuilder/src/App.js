import React, { useEffect, useState } from "react";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import Sidebar from "./component/sidebar/sidebar";
import FormBuilder from "./component/formBuilder/formBuilder";
import Home from "./component/home/home";
import "bootstrap-icons/font/bootstrap-icons.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "./scss/plugins/ant-theme.scss";
import "./scss/style/app.scss";
import Edit from "./component/editbar/edit";
import { Tooltip } from "bootstrap";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { Button, Form, Input, Modal, Result } from "antd";
import { useNavigate } from "react-router-dom";
import { ArrowLeftOutlined, ExclamationCircleOutlined } from "@ant-design/icons";
import axios from "axios";
import "./";

function App() {
  const navigate = useNavigate();
  const [selectedIndexFromFormBuilder, setSelectedIndexFromFormBuilder] =
    useState(null);
    const [selectedSectionItems, setSelectedSectionItems] =
    useState(null);
  const [previewMode, setPreviewMode] = useState(false);
  const [hasFormElements, setHasFormElements] = useState(false);
  const [formElements, setFormElements] = useState([]);
  const [formBuilderId, setFormBuilderId] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [labelText, setLabelText] = useState("Form Builder");
  const [tempLabelText, setTempLabelText] = useState(labelText);
  const [formCreated, setFormCreated] = useState(false);
  const [back, setBack] = useState(false);
  const [formData, setFormData] = useState([]);
  const [isForm, setIsForm] = useState([]);
  const [key, setKey] = useState("");

  console.log("fordmata===>", formData)
  console.log("selecetdformbuilderindex", selectedIndexFromFormBuilder)

  console.log("data ===========> ", formElements);

  const apiEndpoint = process.env.REACT_APP_API_ENDPOINT;

  useEffect(() => {
    const fetchFormData = async () => {
      try {
        const response = await fetch(
          `${apiEndpoint}/forms`,
          {
          headers: {
            'ngrok-skip-browser-warning': 'true'
          }
        }
        );
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        console.log("API Response:", data);
        setFormData(data);
      } catch (error) {
        console.error("Error fetching form data:", error);
      }
    };

    fetchFormData();
  }, []);


  const handleCreateForm = async () => {
    setFormCreated(true);
    // const formId = Math.floor(Math.random() * 1000);
    // navigate(`/form/${formId}`);
    try {
      const data = {
        form: {
          headers_attributes: [{}],
        },
      };

      const result = await axios.post(`${apiEndpoint}/forms`, data, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      // console.log(result);

      setIsForm(result.data);
      setKey(result.data.key);
      const { key } = result.data;
      navigate(`/form/${key}`);
      // navigate(`/form/${key}`, { replace: true });
    } catch (err) {
    } 
  };





  useEffect(() => {
    const tooltipTriggerList = Array.from(
      document.querySelectorAll('[data-bs-toggle="tooltip"]')
    );
    tooltipTriggerList.forEach((tooltipTriggerEl) => {
      new Tooltip(tooltipTriggerEl);
    });
  }, [hasFormElements]);

  useEffect(() => {
    const handlePopState = (event) => {
      setBack(true);
      if (event) {
        Modal.confirm({
          title: "Discard Changes",
          icon: <ExclamationCircleOutlined />,
          content: "Are you sure you want to discard your changes?",
          onOk() {
            setFormCreated(false);
            setIsForm(null);
            setKey(null);
            // setError(null);
            navigate("/", { replace: true });
            window.location.reload();
          },
          onCancel() {
          },
        });
      }
    };

    window.history.pushState({ page: 1 }, "", "");
    window.onpopstate = handlePopState;

    return () => {
      window.onpopstate = null;
    };
  }, [navigate]);

  useEffect(() => {
    const handleBeforeUnload = (event) => {
      if (formCreated && !back) {
        event.preventDefault();
        event.returnValue =
          "You have unsaved changes. Are you sure you want to leave?";
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    if (!formCreated) {
      setFormCreated(false);
      window.history.replaceState(null, "", "/");
      navigate("/");
    }

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [formCreated, back]);

  const handleSelectedIndexChange = (index) => {
    console.log("app index", index)
    setSelectedIndexFromFormBuilder(index);
  };

  const handlePreview = () => {
    setPreviewMode(true);
  };

  const handleExitPreview = () => {
    setPreviewMode(false);
  };

  const handleFormElementsChange = (elements) => {
    setFormElements(elements);
    setHasFormElements(elements.length > 0);
  };

  const handleDownloadForm = async () => {
    const formBuilderArea = document.getElementById(formBuilderId);

    const canvas = await html2canvas(formBuilderArea, {
      scrollY: -window.scrollY,
    });
    const imgData = canvas.toDataURL("image/png");
    const pdfWidth = 210;
    const pdfHeight = 297;
    const ratio = pdfWidth / formBuilderArea.offsetWidth;
    const pdfHeightScaled = formBuilderArea.offsetHeight * ratio;

    const pdf = new jsPDF({
      orientation: pdfHeightScaled < pdfWidth && "portrait",
      unit: "mm",
      format: [pdfWidth, pdfHeight],
    });

    const titleText = labelText;
    const titleX = pdfWidth / 2;
    const titleY = 10;
    pdf.text(titleText, titleX, titleY, { align: "center" });

    let position = 0;
    const pageHeight = pdf.internal.pageSize.height;

    while (position < pdfHeightScaled) {
      pdf.addImage(
        imgData,
        "PNG",
        0,
        20 - position - 9,
        pdfWidth,
        pdfHeightScaled
      );
      position += pageHeight;

      if (position < pdfHeightScaled) {
        pdf.addPage();
      }
    }
    pdf.save("form_builder.pdf");
  };

  const onUpdateElement = (index, updatedElement) => {
    setFormElements((prevElements) => {
      const newElements = [...prevElements];
      newElements[index] = { ...newElements[index], ...updatedElement };
      return newElements;
    });
  };

  const handleClear = () => {
    setFormElements([]);
  };

  useEffect(() => {
    const id = `formBuilder_${Math.random().toString(36).substring(7)}`;
    setFormBuilderId(id);
  }, []);

  const handlePencilClick = () => {
    setTempLabelText(labelText);
    setShowModal(true);
  };

  const handleModalClose = () => {
    setTempLabelText(labelText);
    setShowModal(false);
  };

  const handleModalSave = () => {
    setLabelText(tempLabelText);
    setShowModal(false);
  };

  // console.log(response);

  const handleBack = () => {
    setBack(true);
    Modal.confirm({
      title: "Discard Changes",
      content: "Are you sure you want to discard your changes?",
      onOk() {
        setFormCreated(false);
        setIsForm(null);
        setKey(null);
        // setError(null);
        navigate("/", { replace: true });
        window.location.reload();
      },
    });
  };

  // console.log("back", back);

  const handleFormSave = () => {
    alert("Form saved");
  };

  return (
    <div className="App">
      <DndProvider backend={HTML5Backend}>
        <div
          className="main-container"
          style={{
            position: previewMode ? "fixed" : "",
            backgroundColor: previewMode ? "#e7fbe7" : "#ffffff",
          }}
        >
          {formCreated && !previewMode ? (
            <ArrowLeftOutlined className="back-icon" onClick={handleBack} />
          ) : (
            <img src="/images/logoipsum-330.svg" className="logo-icon" />
          )}

          {formCreated && (
            <label className="builder-title">
              {labelText}{" "}
              <i
                className="bi bi-pencil-fill title-icon"
                onClick={handlePencilClick}
              ></i>
            </label>
          )}
          <div style={{ display: "flex", gap: "20px" }}>
            {formCreated ? (
              <Button
                type="primary"
                // className="btn-configuration-success"
                className="success-btn"
                onClick={handleFormSave}
              >
                Save
              </Button>
            ) : (
              <Button
                 type="primary"
                // className="custom-btn"
                // className="btn-configuration-success"
                 className="success-btn"
                 onClick={handleCreateForm}
              >
                Create
              </Button>
            )}

            {!previewMode && formElements.length === 0 ? (
              <Button type="primary" danger disabled onClick={handleClear}>
                Clear
              </Button>
            ) : (
              !previewMode && (
                <Button
                  type="primary"
                  danger
                  onClick={handleClear}
                  style={{ zIndex: 999 }}
                >
                  Clear
                </Button>
              )
            )}

            {previewMode ? (
              <div className="download-section">
                <Button
                 type="primary" 
                className="secondary-btn" onClick={handleDownloadForm}>
                  Download
                </Button>
                <Button type="primary" danger onClick={handleExitPreview}>
                  Back
                </Button>
              </div>
            ) : (
              <>
                {!hasFormElements && (
                  <div
                    data-bs-toggle="tooltip"
                    data-bs-placement="top"
                    title="Add elements to create form to enable preview"
                    style={{ zIndex: 999 }}
                  >
                    <Button
                      type="primary"
                      disabled={!hasFormElements}
                      onClick={handlePreview}
                    >
                      Preview
                    </Button>
                  </div>
                )}
                {hasFormElements && (
                  <Button className="btn-configuration" onClick={handlePreview}>
                    Preview
                  </Button>
                )}
              </>
            )}
          </div>
        </div>

        <div className={!previewMode ? "app-body" : "app-preview"}>
          {formCreated  ? (
            <>
              {!previewMode && <Sidebar />}
              <FormBuilder
                id={formBuilderId}
                onSelectElementIndex={handleSelectedIndexChange}
                previewMode={previewMode}
                onFormElementsChange={handleFormElementsChange}
                formElements={formElements}x
              />
              {selectedIndexFromFormBuilder !== null
                ? !previewMode && (
                    <Edit
                      selectedIndex={selectedIndexFromFormBuilder}
                      selectedSection = {selectedSectionItems}
                      getElementsData={formElements}
                      onUpdateElement={onUpdateElement}
                    />
                  )
                : !previewMode && (
                    <div className="hide-edit">
                      <Edit />
                    </div>
                  )}
            </>
          ) :
          formData ? <Home formData={formData} /> :
           (
            <Result
              className="empty-builder"
              status="404"
              subTitle="Please create your first form"
            />
          )}
        </div>
      </DndProvider>

      <Modal
        title="Edit Title"
        open={showModal}
        onCancel={handleModalClose}
        className="model-title"
        footer={[
          <Button
            key="cancel"
            // className="btn-cancel"
            className="default-btn"
            onClick={handleModalClose}
          >
            Cancel
          </Button>,
          <Button
            key="submit"
            // className="btn-submit"
            type="primary"
            className="success-btn"
            onClick={handleModalSave}
          >
            Submit
          </Button>,
        ]}
      >
        <Form>
          <Form.Item label="Title" className="text-model">
            <Input
              className="model-title-input"
              value={tempLabelText}
              onChange={(e) => setTempLabelText(e.target.value)}
            />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}

export default App;
