// import { Card, List, Typography } from "antd";
// import React from "react";

// function home({ formData }) {
//   return (
//     <div style={{
//        background: "#dbdbdb", 
//        width: "100%", 
//        height: "100%",
//        borderRadius: '8px',
//        color: 'black',
//         }}>
//       <h1>All Forms</h1>
//       <div style={{ height: "100%" }}>
//         <div style={{ height: "100%" }}>
//           {formData.map((item, index) => (
//             <Card key={index}>{item.title}</Card>
//           ))}
//         </div>
//       </div>
//     </div>
//   );
// }

// export default home;


import React, { useState, useEffect } from "react";
import { Card, Skeleton, Typography } from "antd";

const { Title } = Typography;

const Home = ({ formData }) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (formData && formData.length > 0) {
      setData(formData);
      setLoading(false);
    }
  }, [formData]);

  return (
    <div
      style={{
        background: "#dbdbdb",
        width: "100%",
        height: "100%",
        borderRadius: "8px",
        color: "black",
        padding: "16px",
      }}
    >
      <Title level={1}>All Forms</Title>
      <div style={{ height: "100%" }}>
        <div style={{

            height: 'calc(94vh - 93px)', overflowY: 'scroll' }}>
          {loading ? (
            <Skeleton active />
          ) : (
            data.map((item, index) => (
              <Card key={index} style={{ marginBottom: "16px" }}>
                {item.title} {' '} <strong>{item.key}</strong>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Home;
