import React, { useEffect, useState } from "react";
import { useDrop } from "react-dnd";
import { ItemTypes } from "../../ItemTypes";
import { v4 as uuidv4 } from "uuid";
import DraggableFormElement from "./draggableFormElement";
import { Col, Layout, List, Row, theme } from "antd";
import { Content } from "antd/es/layout/layout";
import { ExclamationCircleOutlined } from "@ant-design/icons";
import { notification } from "antd";
import "../../scss/style/formbuilder.scss"; 
import "../../scss/plugins/ant-theme.scss";

const FormBuilder = ({
  id,
  onSelectElementIndex,
  previewMode,
  onFormElementsChange,
  formElements,
}) => {
  const [selectedElementIndex, setSelectedElementIndex] = useState(null);
  const [showToast, setShowToast] = useState(false);

  useEffect(() => {
    onFormElementsChange(formElements);
  }, [formElements, onFormElementsChange]);

  const [{ isOver }, drop] = useDrop({
    accept: [ItemTypes.ELEMENT, ItemTypes.INPUT, "FORM_ELEMENT"],
    drop: (item, monitor) => {
      const didDrop = monitor.didDrop();
      if (didDrop) return;

      const hoverIndex = findHoverIndex(monitor.getClientOffset());
      addElementToForm(item, hoverIndex);
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  });

  const findHoverIndex = (clientOffset) => {
    const hoverBoundingRect = document
      .getElementById(id)
      ?.getBoundingClientRect();
    const clientY = clientOffset?.y - hoverBoundingRect?.top;

    const breakpoints = formElements?.map((_, index) => {
      const elementRect = document
        .querySelector(`#${id} .form-element-${index}`)
        ?.getBoundingClientRect();
      return elementRect?.top + elementRect?.height / 2;
    });

    for (let i = 0; i < breakpoints?.length; i++) {
      if (clientY < breakpoints[i]) {
        return i;
      }
    }

    return formElements.length;
  };

  const addElementToForm = (item, hoverIndex) => {
    console.log("hhh", hoverIndex)
    const newItem = {
      ...item,
      id: uuidv4(),
      label: item.label || "",
      placeholder: item.placeholder || "",
      value: item.value || "",
      style: { fontFamily: item.style?.fontFamily || "Arial, sans-serif" },
    };

    if (
      formElements[hoverIndex]?.type === "section" &&
      newItem.type === "section"
    ) {
      setShowToast(true);
      setTimeout(() => {
        setShowToast(false);
      }, 1000);
      return;
    }
    if (formElements[hoverIndex]?.type === "section") {
      const updatedElements = [...formElements];
      updatedElements[hoverIndex] = {
        ...updatedElements[hoverIndex],
        items: [...(updatedElements[hoverIndex].items || []), newItem],
      };
      onFormElementsChange(updatedElements);
    } else {
      const updatedElements = [...formElements];
      updatedElements.splice(hoverIndex, 0, newItem);
      onFormElementsChange(updatedElements);
      setSelectedElementIndex(hoverIndex);
      onSelectElementIndex(hoverIndex);
    }
  };

  const handleDelete = (index) => {
    const updatedElements = [...formElements];
    updatedElements.splice(index, 1);
    onFormElementsChange(updatedElements);
    setSelectedElementIndex(null);
  };

  const handleDeleteSubitem = (parentIndex, subIndex) => {

    // console.log(subIndex)
    // return

    const updatedElements = [...formElements];
    const parentElement = updatedElements[parentIndex];

    if (parentElement && parentElement.items) {
      parentElement.items.splice(subIndex, 1);
      onFormElementsChange(updatedElements);
      setSelectedElementIndex(null);
    }
  };

  const handleElementClick = (index, e) => {
    e.stopPropagation();
    if (!previewMode) {
      const newIndex = index === selectedElementIndex ? null : index;
      setSelectedElementIndex(newIndex);

      if (typeof index === "string") {
        const [parentIndex, subIndex] = index.split("-").map(Number);
        if (subIndex !== undefined) {
          // localStorage.setItem("items", JSON.stringify(formElements[parentIndex].items[subIndex]))
          console.log("Selected Subitem:",formElements[parentIndex].items[subIndex]);
          setSelectedElementIndex(newIndex);
        } else {
          console.log("Selected Element1:", formElements[newIndex]);
          setSelectedElementIndex(newIndex);
        }
      } else {
        console.log("Selected Element2:", formElements[newIndex]);
        setSelectedElementIndex(newIndex);
      }

      onSelectElementIndex(newIndex);
    }
  };

  const handleUpdateElement = (index, updatedElement, parentIndex) => {
    const updatedElements = [...formElements];
    updatedElements[index] = { ...updatedElements[index], ...updatedElement };
    onFormElementsChange(updatedElements);
  };

  const [elements, setElements] = useState(formElements || []);
  useEffect(() => {
    setElements(formElements || []);
  }, [formElements]);

  const moveElement = (dragIndex, hoverIndex, parentIndex) => {
    const updatedElements = [...formElements];
  
    if (parentIndex !== null) {
      // Move within a section
      console.log("moving in section")
      const parentElement = updatedElements[parentIndex];
      const [draggedElement] = parentElement.items.splice(dragIndex, 1);
      parentElement.items.splice(hoverIndex, 0, draggedElement);
    } else {
      // Move outside of sections
      console.log("moving out section")
      const [draggedElement] = updatedElements.splice(dragIndex, 1);
      updatedElements.splice(hoverIndex, 0, draggedElement);
    }
  
    onFormElementsChange(updatedElements);
    setSelectedElementIndex(hoverIndex);
    onSelectElementIndex(hoverIndex);
  };
  

  const openNotification = () => {
    notification.error({
      message: "Error",
      description: "You cannot add section inside section.",
      icon: <ExclamationCircleOutlined style={{ color: "#ff4d4f" }} />,
      placement: "top",
      duration: 1,
    });
  };

  useEffect(() => {
    if (showToast) {
      openNotification();
    }
  }, [showToast]);

  return (
    <Layout className={`form-builder ${previewMode ? "preview-mode" : ""}`}>
      <Content
        id={id}
        ref={drop}
        style={{
          width: "100%",
          height: "100%",
          padding: previewMode ? "20px" : "",
        }}
        className={`form-canvas ${isOver ? "drag-over" : ""}`}
      >
        {formElements.length === 0 && (
          <List.Item
            className="emptyPlaceholderLine disable-drag placeholder-text"
            tabIndex="0"
          >
            <div className="stage-empty isSmall">
              <div>
                <span name="enlarge" className="ji ji-enlarge"></span>
              </div>
              <div>Drag your first question here from the left.</div>
            </div>
          </List.Item>
        )}
        <Row style={{ alignItems: "center", padding: '20px 0' }}>
          {formElements.map((element, index) => (
            <Col
              key={index}
              span={element.style?.width || 24}
              //  style={{ width: element.style?.width || "100%" }}
            >
              <DraggableFormElement
                key={index}
                index={index}
                element={element}
                // moveElement={moveElement}
                moveElement={(dragIndex, hoverIndex) => moveElement(dragIndex, hoverIndex, null)}
                selectedElementIndex={selectedElementIndex}
                handleElementClick={handleElementClick}
                handleUpdateElement={(
                  updatedIndex,
                  updatedElement,
                  parentIndex
                ) =>
                  handleUpdateElement(updatedIndex, updatedElement, parentIndex)
                }
                handleDelete={handleDelete}
                handleDeleteSubitem={handleDeleteSubitem}
                previewMode={previewMode}
                parentIndex={null}
                onSelectSection={() => setSelectedElementIndex(index)}
              />
            </Col>
          ))}
        </Row>
      </Content>
    </Layout>
  );
};

export default FormBuilder;
