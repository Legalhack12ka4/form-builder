import { Col, Input, Rate, Row } from "antd";
import TextArea from "antd/es/input/TextArea";
import React from "react";
import { useDrag, useDrop } from "react-dnd";
import ReCAPTCHA from "react-google-recaptcha";

const ElementLabel = ({ element }) => {
  const defaultFontSize = element?.type === "header" ? "48px" : "16px";

  return (
    <label
      style={{
        fontSize: element.style?.fontSize || defaultFontSize,
        color: element.style?.color || "#000000",
        textTransform: element.style?.textTransform || "none",
        justifyContent: element.style?.justifyContent || "left",
        display: element.style?.display || "flex",
        fontWeight: element.style?.fontWeight || "normal",
        fontStyle: element.style?.fontStyle || "normal",
      }}
    >
      {element?.type === "button" ||
      element?.type === "section" ||
      element?.type === "tool"
        ? ""
        : element?.label}
      {element?.required && (
        <span style={{ color: "red", marginLeft: "5px" }}>*</span>
      )}
    </label>
  );
};

const ElementInput = ({ element, index, handleUpdateElement, previewMode }) => (
  <>
    {["input", "phone", "email"]?.includes(element?.type) && (
      <Input
        type={element.type}
        className="form-control no-focus-shadow"
        value={element?.value || ""}
        onChange={(e) => handleUpdateElement(index, { value: e.target.value })}
        placeholder={element?.placeholder || ""}
        style={{
          pointerEvents: !previewMode ? "none" : "auto",
          color: element.style?.color || "",
          fontSize: element.style?.fontSize || "16px",
          textTransform: element.style?.textTransform || "none",
          fontWeight: element.style?.fontWeight || "normal",
          fontStyle: element.style?.fontStyle || "normal",
        }}
        required={element?.required}
        disabled={element?.disabled}
        readOnly={!previewMode}
      />
    )}
    {element.type === "textarea" && (
      <TextArea
        className="form-control"
        value={element.value || ""}
        onChange={(e) => handleUpdateElement(index, { value: e.target.value })}
        placeholder={element?.placeholder || ""}
        style={{
          pointerEvents: !previewMode ? "none" : "auto",
          color: element.style?.color || "",
          fontSize: element.style?.fontSize || "16px",
          textTransform: element.style?.textTransform || "none",
          fontWeight: element.style?.fontWeight || "normal",
          fontStyle: element.style?.fontStyle || "normal",
          resize: element.style?.resize || "none",
        }}
        required={element.required}
        disabled={element.disabled}
        readOnly={!previewMode}
      />
    )}
    {element.type === "captcha" && (
      <ReCAPTCHA
        sitekey="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"
        onChange={(value) => handleUpdateElement(index, { value })}
        theme="light"
        style={{
          justifyContent: element.style?.justifyContent || "left",
          display: "flex",
        }}
      />
    )}
    {element.type === "scale" && (
      <div
        className="scale-rating"
        style={{
          display: "flex",
          justifyContent: "space-between",
          gap: "5px",
          // width: "100%",
        }}
      >
        {[1, 2, 3, 4, 5].map((value) => (
          <div
            key={value}
            onClick={() => handleUpdateElement(index, { value })}
            style={{
  
          cursor: "pointer",
          padding: "5px",
          width: "30px",
          height: "30px",
          borderRadius: "50%",
          backgroundColor: element.value === value ? "green" : "#ededed",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          color: "white",
          fontWeight: "bold",
        }}
          >
            {value}
          </div>
        ))}
      </div>
    )}
    {element.type === "star" && (
      <Rate
        count={5}
        value={element.value}
        onChange={(value) => handleUpdateElement(index, { value })}
        style={{
          fontSize: 24,
          color: "#fadb14",
          pointerEvents: !previewMode ? "none" : "auto",
          justifyContent: element.style?.justifyContent || "left",
          display: "flex",
        }}
      />
    )}
  </>
);

const DraggableFormElement = ({
  element,
  index,
  moveElement,
  selectedElementIndex,
  setSelectedElementIndex,
  handleElementClick,
  handleUpdateElement,
  handleDelete,
  handleDeleteSubitem,
  previewMode,
  parentIndex,
  onSelectSection,
}) => {
  const isSelected = selectedElementIndex === index;

  // for outside element
  const [{ isDragging }, drag] = useDrag({
    type: "FORM_ELEMENT",
    item: { index },
    canDrag: isSelected && !previewMode,
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  });

  const [, drop] = useDrop({
    accept: "FORM_ELEMENT",
    hover: (draggedItem) => {
      if (draggedItem.index !== index) {
        moveElement(draggedItem.index, index);
        draggedItem.index = index;
      }
    },
  });

  // const isSelected = selectedElementIndex === index;

  // const [{ isDragging }, drag] = useDrag({
  //   type: 'FORM_ELEMENT',
  //   item: { index, parentIndex },
  //   canDrag: isSelected && !previewMode,
  //   collect: (monitor) => ({
  //     isDragging: !!monitor.isDragging(),
  //   }),
  // });

  // const [{ isOver }, drop] = useDrop({
  //   accept: 'FORM_ELEMENT',
  //   hover: (draggedItem) => {
  //     if (draggedItem.index !== index) {
  //       moveElement(draggedItem?.index, `${index}-${element?.items?.length}`, draggedItem.parentIndex, index);
  //       draggedItem.index = `${index}-${element?.items?.length}`;
  //       draggedItem.parentIndex = index;
  //     }
  //   },
  //   drop: (item, monitor) => {
  //     const didDrop = monitor.didDrop();
  //     if (didDrop) return;

  //     moveElement(item.index, `${index}-${element?.items?.length}`, item.parentIndex, index);
  //     item.index = `${index}-${element?.items?.length}`;
  //     item.parentIndex = index;
  //   },
  //   collect: (monitor) => ({
  //     isOver: monitor.isOver(),
  //   }),
  // });

  const handleSubitemClick = (parentIndex, subIndex, e) => {
    alert("ssss");
    e.stopPropagation();
    if (!previewMode) {
      const compositeIndex = `${parentIndex}-${subIndex}`;
      const newIndex =
        compositeIndex === selectedElementIndex ? null : compositeIndex;
      //    setSelectedElementIndex(newIndex);
      console.log("Selected Subitem:", compositeIndex);
    }
  };

  const opacity = isDragging ? 0.4 : 1;

  return (
    <>
      {element?.type !== undefined && (
        <div
          ref={(node) => drag(drop(node))}
          className={`form-element form-element-${index} ${
            isSelected && !previewMode ? "selected" : ""
          } ${isDragging ? "dragging" : ""}`}
        >
          {element.type === "section" && (
            <Row
              className="section-container card-style"
              style={{
                backgroundColor: element.style?.backgroundColor || "#ffffff",
              }}
              ref={(node) => drop(node)}
              onClick={(e) => {
                console.log("Clicked on section:", index);
                onSelectSection();
                handleElementClick(index, e);
              }}
            >
              {element.items &&
                element.items.map((nestedElement, nestedIndex) => (
                  <Col
                    span={nestedElement.style?.width || 24}
                    key={`nested_${nestedIndex}`}
                    onClick={(e) => handleSubitemClick(index, nestedIndex, e)}
                    className={`form-element-${index}-${nestedIndex} ${
                      selectedElementIndex === `${index}-${nestedIndex}` &&
                      !previewMode
                        ? "selected"
                        : ""
                    }`}
                  >
                    <DraggableFormElement
                      element={nestedElement}
                      index={`${index}-${nestedIndex}`}
                      moveElement={moveElement}
                      selectedElementIndex={selectedElementIndex}
                      setSelectedElementIndex={setSelectedElementIndex}
                      handleElementClick={handleElementClick}
                      handleUpdateElement={handleUpdateElement}
                      handleDelete={() =>
                        handleDeleteSubitem(index, nestedIndex)
                      }
                      handleDeleteSubitem={handleDeleteSubitem}
                      previewMode={previewMode}
                      parentIndex={index}
                      onSelectSection={() => setSelectedElementIndex(index)}
                    />
                  </Col>
                ))}
            </Row>
          )}
          <div
            ref={(node) => drag(drop(node))}
            className={`${element.type}-item`}
            onClick={(e) => handleElementClick(index, e)}
            style={{ opacity, cursor: previewMode ? "default" : "move",
              display: element.type ==="captcha" ? "flex" : element?.style?.display || 'grid',
              justifyContent: element?.style?.justifyContent || 'left',
              alignItems: 'center',
             }}
          >
            <ElementLabel element={element} />
            {[
              "input",
              "textarea",
              "phone",
              "email",
              "captcha",
              "scale",
              "star",
            ].includes(element.type) && (
              <ElementInput
                element={element}
                index={index}
                handleUpdateElement={handleUpdateElement}
                previewMode={previewMode}
              />
            )}

            {element.type === "button" && (
              <div
                style={{
                  justifyContent: element.style?.justifyContent || "left",
                  display: "flex",
                }}
              >
                <button
                  type={element.type}
                  className="btn btn-primary"
                  style={{
                    fontSize: element.style?.fontSize || "16px",
                    color: element.style?.color || "#ffffff",
                    backgroundColor:
                      element.style?.backgroundColor || "#0d6efd",
                    textTransform: element.style?.textTransform || "capitalize",
                    fontWeight: element.style?.fontWeight || "normal",
                    fontStyle: element.style?.fontStyle || "normal",
                    border: "none",
                  }}
                >
                  {element.label}
                </button>
              </div>
            )}
            {element.type === "tool" && (
              <div
                style={{
                  justifyContent: element.style?.justifyContent || "left",
                  display: "flex",
                }}
              >
                <hr
                  style={{
                    border: "1px solid #c1c1c1",
                    width: "100%",
                    margin: 0,
                  }}
                />
              </div>
            )}
          </div>
          {isSelected && !previewMode && (
            <div
              className="element-options"
              style={{
                display: "flex",
                gap: "10px",
                padding: "2px 10px",
                position: "absolute",
                top: 0,
                right: 0,
              }}
            >
              <div>
                <button
                  className="btn btn-link text-danger"
                  onClick={() => handleDelete(index)}
                >
                  <i className="bi bi-trash"></i>
                </button>
              </div>
              <div>
                <div
                  className="drag-handle"
                  ref={(node) => drag(drop(node))}
                  style={{ cursor: "move" }}
                >
                  <button className="btn btn-link" style={{ color: "gray" }}>
                    <i className="bi bi-grip-vertical"></i>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </>
  );
};

export default DraggableFormElement;
