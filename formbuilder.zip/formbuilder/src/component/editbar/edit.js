import React, { useState } from "react";
import "../../scss/style/edit.scss";
import "../../scss/plugins/ant-theme.scss";
import {
  Col,
  Divider,
  Input,
  Layout,
  Radio,
  Select,
  Switch,
  Typography,
} from "antd";
import Sider from "antd/es/layout/Sider";

const { Option } = Select;

const textTransforms = [
  { label: "Capitalize", value: "capitalize" },
  { label: "UPPERCASE", value: "uppercase" },
  { label: "lowercase", value: "lowercase" },
  { label: "None", value: "none" },
];

const positions = ["Left", "Center", "Right"].map((label) => ({
  label,
  value: label.toLowerCase(),
}));

const alignment = ["Space-Between", "Space-Around"].map((label) => ({
  label,
  value: label.toLowerCase(),
}));

const buttonType = ["Button", "Submit", "Reset"].map((label) => ({
  label,
  value: label.toLowerCase(),
}));

const fontWeights = [
  "100",
  "200",
  "300",
  "400",
  "500",
  "600",
  "700",
  "800",
  "900",
  "Bold",
  "Bolder",
  "Lighter",
  "Normal",
].map((label) => ({ label, value: label.toLowerCase() }));

const fontStyles = ["Normal", "Italic"].map((label) => ({
  label,
  value: label.toLowerCase(),
}));

const widthStyle = ["24", "12", "10", "8", "6", "4", "2"].map((label) => ({
  label,
  value: label.toLowerCase(),
}));

const Edit = ({ selectedIndex, getElementsData, onUpdateElement }) => {
  const [showValue, setShowValue] = useState("flex");
  console.log("edit", selectedIndex, getElementsData, onUpdateElement);

  // const getNestedElement = (index) => {
  //   const indices = index?.split?.('-')?.map(i => parseInt(i, 10));
  //   let element = getElementsData;
  //   indices?.forEach(i => {
  //     element = (element?.items || element)?.[i];
  //   });
  //   return element;
  // };

  // const handleChange = (property, value) => {
  //   const updateElement = (element, indices) => {
  //     if (indices.length === 1) {
  //       element[indices[0]] = { ...element[indices[0]], [property]: value };
  //     } else {
  //       const [firstIndex, ...restIndices] = indices;
  //       updateElement(element[firstIndex].items, restIndices);
  //     }
  //   };

  //   const updatedElementsData = [...getElementsData];
  //   const indices = selectedIndex?.split('-').map(i => parseInt(i, 10));
  //   updateElement(updatedElementsData, indices);
  //   onUpdateElement(updatedElementsData);
  // };

  // const element= getElementsData?.[selectedIndex]

  // const handleChange = (property, value) => {

  //   onUpdateElement(selectedIndex, { ...element, [property]: value });
  // };

  const isNested = selectedIndex?.includes?.("-");

  const getNestedElement = (index) => {
    const indices = index?.split?.("-")?.map((i) => parseInt(i, 10));
    let element = getElementsData;
    indices?.forEach((i) => {
      element = (element?.items || element)?.[i];
    });
    return element;
  };

  const element = isNested
    ? getNestedElement(selectedIndex)
    : getElementsData?.[selectedIndex];

  const handleChange = (property, value) => {
    if (isNested) {
      const updateElement = (element, indices) => {
        if (indices.length === 1) {
          element[indices[0]] = { ...element[indices[0]], [property]: value };
        } else {
          const [firstIndex, ...restIndices] = indices;
          updateElement(element[firstIndex].items, restIndices);
        }
      };

      const updatedElementsData = [...getElementsData];
      const indices = selectedIndex?.split("-").map((i) => parseInt(i, 10));
      updateElement(updatedElementsData, indices);
      onUpdateElement(updatedElementsData);
    } else {
      onUpdateElement(selectedIndex, { ...element, [property]: value });
    }
  };

  const handleResizeChange = (property, value) => {
    if(property === "captcha")
    {
      setShowValue(value);
    }
    const updatedElement = {
      ...element,
      style: {
        ...element.style,
        [property]: value,
      },
    };
    onUpdateElement(selectedIndex, updatedElement);
  };
  console.log("showValue", showValue);

  const renderShowTextSettings = () => (
    <div className="switch-container" style={{ marginTop: 0 }}>
      <Typography className="edit-sections-name">Hide Text</Typography>
      <Switch
        className="switch-data"
        checked={element.style?.display === "none"}
        onChange={(checked) =>
          handleResizeChange("display", checked ? "none" : "flex")
        }
      />
    </div>
  );

  const renderTextSettings = () => (
    <div className="edit-group">
      <div className="edit-sections">
        <Typography className="sections-name">General</Typography>
      </div>
      {element.type == "captcha" &&
      <>
      {renderShowTextSettings()}
      </> 
      }

      {showValue === "flex" && (
        <>
          <Typography className="edit-sections-name">Text</Typography>
          <Input
            className="input-data"
            type="text"
            value={element.label}
            onChange={(e) => handleChange("label", e.target.value)}
          />
          {element.type !== "header" &&
            element.type !== "button" &&
            element.type !== "captcha" &&
            element.type !== "star" &&
            element.type !== "scale" &&
            element.type !== "text" && (
              <>
                <div className="edit-group">
                  <Typography className="edit-sections-name">
                    Placeholder
                  </Typography>
                  <Input
                    type="text"
                    className="input-data"
                    value={element.placeholder}
                    onChange={(e) =>
                      handleChange("placeholder", e.target.value)
                    }
                  />
                </div>
              </>
            )}

          <Typography className="edit-sections-name">Text Transform</Typography>
          <Select
            className="option-field"
            value={element.style?.textTransform || "capitalize"}
            onChange={(value) =>
              handleChange("style", {
                ...element.style,
                textTransform: value,
              })
            }
          >
            {textTransforms.map((transform) => (
              <Option key={transform?.value} value={transform?.value}>
                {transform?.label}
              </Option>
            ))}
          </Select>
          {element.type !== "section" && (
            <>
              <Typography className="edit-sections-name">Color</Typography>
              <Input
                style={{ width: "100%" }}
                type="color"
                value={
                  element.style?.color ||
                  (element.type === "button" ? "#ffffff" : "#000000")
                }
                onChange={(e) =>
                  handleChange("style", {
                    ...element.style,
                    color: e.target.value,
                  })
                }
              />
            </>
          )}
          {(element.type === "button" || element.type === "section") && (
            <>
              <Typography className="edit-sections-name">
                Background Color
              </Typography>
              <Input
                style={{ width: "100%" }}
                type="color"
                value={
                  element.style?.backgroundColor ||
                  (element.type === "button"
                    ? "#0d6efd"
                    : element.type === "section"
                    ? "#ffffff"
                    : "#000000")
                }
                onChange={(e) =>
                  handleChange("style", {
                    ...element.style,
                    backgroundColor: e.target.value,
                  })
                }
              />
            </>
          )}
        </>
      )}
    </div>
  );

  const renderFontSettings = () => (
    <div className="edit-group">
      <div className="edit-sections">
        <Typography className="sections-name">Text Style</Typography>
      </div>
      <Typography className="edit-sections-name">Font Size</Typography>
      <Input
        type="number"
        value={
          parseInt(element.style?.fontSize) ||
          (element.type === "header" ? 48 : 16)
        }
        onChange={(e) => {
          let value = e.target.value.trim();
          if (!isNaN(value)) {
            value += "px";
          }
          handleChange("style", { ...element.style, fontSize: value });
        }}
        className="form-control input-data"
        placeholder="Enter font size"
      />
      <Typography className="edit-sections-name">Font Weight</Typography>
      <Select
        className="option-field"
        value={element.style?.fontWeight || "normal"}
        onChange={(value) =>
          handleChange("style", {
            ...element.style,
            fontWeight: value,
          })
        }
      >
        {fontWeights.map((weights) => (
          <Option key={weights.value} value={weights.value}>
            {weights.label}
          </Option>
        ))}
      </Select>
      <Typography className="edit-sections-name">Font Style</Typography>
      <Col className="position-radio-group">
        {fontStyles.map((sty, index) => (
          <label key={sty.value} className="position-radio-label">
            <Radio.Group
              className="edit-radio-group"
              value={element.style?.fontStyle || "normal"}
              onChange={(e) =>
                handleChange("style", {
                  ...element.style,
                  fontStyle: e.target.value,
                })
              }
              buttonStyle="solid"
              style={{ display: "flex", width: "100%" }}
            >
              <Radio.Button
                key={sty.value}
                value={sty.value}
                style={{
                  borderRadius:
                    index === 0
                      ? "4px 0 0 4px"
                      : index === fontStyles.length - 1
                      ? "0 4px 4px 0"
                      : "0",
                  borderLeftWidth: index !== 0 ? 0 : undefined,
                }}
              >
                <span style={{ padding: "0 41px" }}>{sty.label}</span>
              </Radio.Button>
            </Radio.Group>
          </label>
        ))}
      </Col>
    </div>
  );

  const renderDeafultValueSettings = () => (
    <div className="edit-group">
      <div className="edit-sections">
        <Typography className="sections-name">Value</Typography>
      </div>
      <Typography className="edit-sections-name">Default Value</Typography>
      <Input
        type={element.type === "phone" ? "number" : "text"}
        value={element.value}
        onChange={(e) => handleChange("value", e.target.value)}
      />
    </div>
  );

  const renderCustomSettings = () => (
    
    <div className="edit-group">
      <div className="edit-sections">
        <Typography className="sections-name">Settings</Typography>
      </div>
      <Typography className="edit-sections-name">Position</Typography>
      <div className="position-radio-group">
        {positions
        .map((pos, index) => (
          <label key={pos.value} className="position-radio-label">
            <Radio.Group
              className="edit-radio-group"
              value={element.style?.justifyContent || "left"}
              onChange={(e) =>
                handleChange("style", {
                  ...element.style,
                  justifyContent: e.target.value,
                })
              }
              buttonStyle="solid"
            >
              <Radio.Button
                key={pos.value}
                value={pos.value}
                style={{
                  borderRadius:
                    index === 0
                      ? "4px 0 0 4px"
                      : index === positions.length - 1
                      ? "0 4px 4px 0"
                      : "0",
                  borderLeftWidth: index !== 0 ? 0 : undefined,
                }}
              >
                <span style={{ padding: "0 18.5px" }}>{pos.label}</span>
              </Radio.Button>
            </Radio.Group>
          </label>
        ))}

      </div>
      {element.type !== "header" &&
        element.type !== "button" &&
        element.type !== "captcha" &&
        element.type !== "star" &&
        element.type !== "scale" &&
        element.type !== "text" && (
          <>
            <div className="switch-container">
              <Typography className="edit-sections-name">Required</Typography>
              <Switch
                className="switch-data"
                checked={element.required || false}
                onChange={(checked) => handleChange("required", checked)}
              />
            </div>
            <div className="switch-container" style={{ marginTop: 0 }}>
              <Typography className="edit-sections-name">Disabled</Typography>
              <Switch
                className="switch-data"
                checked={element.disabled || false}
                onChange={(checked) => handleChange("disabled", checked)}
              />
            </div>
            {element.type === "textarea" && (
              <div className="switch-container" style={{ marginTop: 0 }}>
                <Typography className="edit-sections-name">
                  Field Resize
                </Typography>
                <Switch
                  className="switch-data"
                  checked={element.style?.resize === "auto"}
                  onChange={(checked) =>
                    handleResizeChange("resize", checked ? "auto" : "none")
                  }
                />
              </div>
            )}
          </>
        )}

      {
        (element.type === "star" || 
        element.type === "scale") && (<>
        <Typography className="edit-sections-name">Alignment Text</Typography>
        <div className="position-radio-group">
        {alignment
        .map((pos, index) => (
          <label key={pos.value} className="position-radio-label">
            <Radio.Group
              className="edit-radio-group"
              value={element.style?.justifyContent || "left"}
              onChange={(e) =>
                handleChange("style", {
                  ...element.style,
                  justifyContent: e.target.value,
                })
              }
              buttonStyle="solid"
            >
              <Radio.Button
                key={pos.value}
                value={pos.value}
                style={{
                  borderRadius:
                    index === 0
                      ? "4px 0 0 4px"
                      : index === fontStyles.length - 1
                      ? "0 4px 4px 0"
                      : "0",
                  borderLeftWidth: index !== 0 ? 0 : undefined,
                }}
              >
                <span style={{ padding: "0 14px" }}>{pos.label}</span>
              </Radio.Button>
            </Radio.Group>
          </label>
        ))}
      </div>
      </>)
      }

      {
        element.type !== "captcha" &&

        <div className="switch-container" style={{ marginTop: 0 }}>
        <Typography className="edit-sections-name">Row</Typography>
        <Switch
        className="switch-data"
        checked={element.style?.display === "flex"}
        onChange={(checked) =>
          handleResizeChange("display", checked ? "flex" : "grid")
        }
      />
      </div>

      }
    </div>
  );

  const renderButtonSettings = () => (
    <>
      {renderWidthSettings()}
      <Divider className="edit-section-divider" />
      {renderTextSettings()}
      <Divider className="edit-section-divider" />
      {renderFontSettings()}
      <Divider className="edit-section-divider" />
      {renderCustomSettings()}
      <div className="edit-group top">
        <Typography className="edit-sections-name">Button Type</Typography>
        <Select
          className="option-field"
          value={element.buttonType || ""}
          onChange={(value) => handleChange("buttonType", value)}
        >
          {buttonType.map((type) => (
            <Option key={type.value} value={type.value}>
              {type.label}
            </Option>
          ))}
        </Select>
      </div>
    </>
  );

  const renderCaptchaSettings = () => (
    <>
      {renderTextSettings()}
      {showValue === "flex" && (
        <>
          <Divider className="edit-section-divider" />
          {renderFontSettings()}
        </>
      )}
      <Divider className="edit-section-divider" />
      {renderCustomSettings()}
    </>
  );

  const renderWidthSettings = () => (
    <div
      className="edit-group"
      style={{
        marginBottom: element.length - 1 ? "12px" : "0",
      }}
      s
    >
      <div className="edit-sections">
        <Typography className="sections-name">Shrink Field</Typography>
      </div>
      <Typography className="edit-sections-name">Width</Typography>
      <Select
        className="option-field"
        value={element.style?.width || "Full"}
        onChange={(value) =>
          handleChange("style", {
            ...element.style,
            width: value,
          })
        }
      >
        {widthStyle.map((transform) => (
          <Option key={transform.value} value={transform.value}>
            {transform.label}
          </Option>
        ))}
      </Select>
    </div>
  );

  return (
    <Layout className="editbar">
      <Sider width={350} className="site-layout-background">
        <div className="edit-header">
          <h3>Element Configurations</h3>
        </div>
        {element?.type && (
          <div className="edit-elements">
            {element.type === "captcha" ? (
              renderCaptchaSettings()
            ) : element.type === "button" ? (
              renderButtonSettings()
            ) : element.type === "section" ? (
              <Typography className="sections-name">
                Please select inner elements
              </Typography>
            ) : (
              <>
                {renderWidthSettings()}
                <Divider className="edit-section-divider" />
                {renderTextSettings()}
                <Divider className="edit-section-divider" />
                {element.type !== "header" &&
                  element.type !== "text" &&
                  element.type !== "star" &&
                  element.type !== "scale" &&
                  renderDeafultValueSettings()}
                {["input", "phone", "email", "textarea"]?.includes(
                  element?.type
                ) && <Divider className="edit-section-divider" />}
                {renderFontSettings()}
                <Divider className="edit-section-divider" />
                {renderCustomSettings()}
              </>
            )}
          </div>
        )}
        {!element?.type && (
          <div className="empty-editbar">No element selected yet</div>
        )}
      </Sider>
    </Layout>
  );
};

export default Edit;
