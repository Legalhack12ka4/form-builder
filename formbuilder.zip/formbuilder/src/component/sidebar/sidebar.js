import React, { useState } from "react";
import { useDrag } from "react-dnd";
import { ItemTypes } from "../../ItemTypes";
import {
  Card,
  Input,
  Divider,
  Layout,
  Row,
  Col,
  Typography,
  Empty,
  theme,
} from "antd";
import {
  AntDesignOutlined,
  BarChartOutlined,
  FileTextFilled,
  MailFilled,
  MessageFilled,
  PhoneFilled,
  SearchOutlined,
  SecurityScanFilled,
  StarFilled,
} from "@ant-design/icons";
import { Minus, Shield } from "react-feather";
// import "./Sidebar.css";
// import '../../pluginsSaas/sidebar.scss'
import "../../scss/style/sidebar.scss";
import "../../scss/plugins/ant-theme.scss";

const { Sider } = Layout;
const { Title } = Typography;

const DraggableItem = ({ type, label, placeholder, icon, value }) => {
  const [{ isDragging }, drag] = useDrag({
    type: ItemTypes.ELEMENT,
    // type: ItemTypes.INPUT,
    item: { type, label, placeholder, value },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  });

  return (
    <Col
      ref={drag}
      className={`sidebar-item ${isDragging ? "dragging" : ""}`}
      span={24}
    >
      <Card className="card-container">
        <div className="card-body">
          <i className="card-icons">{icon}</i>
          {label}
        </div>
      </Card>
    </Col>
  );
};

const sections = [
  {
    section: "Section",
    items: [{ type: "section", label: "Section", icon: <AntDesignOutlined /> }],
  },
  {
    section: "Text",
    items: [
      { type: "header", label: "Header", icon: <MessageFilled /> },
      { type: "text", label: "Text", icon: <FileTextFilled /> },
    ],
  },
  {
    section: "Input",
    items: [
      {
        type: "input",
        label: "Input",
        placeholder: "Input Placeholder",
        value: "",
        icon: <MailFilled />,
      },
      {
        type: "textarea",
        label: "Address",
        placeholder: "Address Placeholder",
        value: "",
        icon: <MailFilled />,
      },
      {
        type: "phone",
        label: "Phone",
        placeholder: "Number Placeholder",
        value: "",
        icon: <PhoneFilled />,
      },
      {
        type: "email",
        label: "Email",
        placeholder: "Email Placeholder",
        value: "",
        icon: <MailFilled />,
      },
    ],
  },
  {
    section: "Rating",
    items: [
      {
        type: "scale",
        label: "Scale",
        value: "",
        icon: <BarChartOutlined />,
      },
      {
        type: "star",
        label: "Star",
        value: "",
        icon: <StarFilled />,
      },
    ],
  },
  {
    section: "Button",
    items: [{ type: "button", label: "Button", icon: <MailFilled /> }],
  },
  {
    section: "Captcha",
    items: [
      {
        type: "captcha",
        label: "Captcha",
        // theme: "light",
        value: "",
        icon: <SecurityScanFilled />,
      },
    ],
  },

  {
    section: "Divider",
    items: [{ type: "tool", label: "Divider", icon: <Minus /> }],
  },
];

const Sidebar = () => {
  const [searchTerm, setSearchTerm] = useState("");

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const filteredSections = sections
    .map((section) => ({
      ...section,
      items: section.items.filter((item) =>
        item.label.toLowerCase().includes(searchTerm.toLowerCase())
      ),
    }))
    .filter(
      (section) =>
        section.items.length > 0 ||
        section.section.toLowerCase().includes(searchTerm.toLowerCase())
    );

  return (
    <Layout className="sidebar-main-container">
      <Sider width={300} className="site-layout-background">
        <div className="sidebar">
          <Col span={24} className="sidebar-header">
            <Title level={3}>Form Elements</Title>
          </Col>
          <Col span={24} className="sidebar-search">
            <SearchOutlined className="search-icon" />
            <Input
              type="text"
              className="form-control search-input no-focus-shadow"
              placeholder="Search here"
              aria-label="Search elements"
              aria-describedby="search-icon"
              value={searchTerm}
              onChange={handleSearchChange}
            />
          </Col>
          <Col span={24}>
            <Divider style={{ margin: 0 }} />
          </Col>
          <Col span={24} className="sidebar-container">
            {filteredSections.length === 0 ? (
              <Empty description="No element found" />
            ) : (
              filteredSections.map((section, index) => (
                <Row key={index} className="sidebar-section">
                  <Col span={24}>
                    <Typography className="element-sections">
                      {section.section}
                    </Typography>
                  </Col>
                  <Col
                    span={24}
                    className={
                      section.items.some((item) => item.type === "section")
                        ? "section-container"
                        : "element-cards-UI"
                    }
                    style={{
                      marginBottom:
                        index === filteredSections.length - 1 ? "0" : "25px",
                    }}
                  >
                    {section.items.map((item, itemIndex) => (
                      <DraggableItem
                        key={`${index}_${itemIndex}`}
                        type={item.type}
                        label={item.label}
                        placeholder={item.placeholder}
                        value={item.value}
                        icon={item.icon}
                      />
                    ))}
                  </Col>
                </Row>
              ))
            )}
          </Col>
        </div>
      </Sider>
    </Layout>
  );
};

export default Sidebar;
