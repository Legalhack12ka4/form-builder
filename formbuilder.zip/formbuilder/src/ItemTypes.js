export const ItemTypes = {
  ELEMENT: 'ELEMENT',
  INPUT: 'INPUT',
  // SECTION: 'SECTION',
  FORM_ELEMENT: 'FORM_ELEMENT',
  // CARD: 'CARD',
};
